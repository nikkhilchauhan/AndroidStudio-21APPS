# Abot
# An IBM watson chat bot
Source code for the video available at https://youtu.be/m7ASRWdgdAg (Part 1)
This will a chat bot for android which uses IBM Watson's Conversation API
# Development
Development will be branch based, for now master branch contains the code for part 1, but after second video master branch will have the 
code for Video 1+Video 2 and current video's code will got the feature branch and this will be repeated till the project is complete.
